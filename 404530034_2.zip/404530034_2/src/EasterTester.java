import java.util.Scanner;
public class EasterTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello,users!");
		Easter easter = new Easter();
		
		Scanner scan = new Scanner(System.in);
		System.out.println("�п�J�~��");
		int aYear1 = scan.nextInt();
		System.out.println(easter.calculateEaster(aYear1));
		
		
		System.out.println("�п�J�~��");
		int aYear2 = scan.nextInt();
		System.out.println(easter.calculateEaster(aYear2));
	}

}
