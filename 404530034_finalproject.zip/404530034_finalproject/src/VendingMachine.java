import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import java.awt.Panel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.Font;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JOptionPane;

public class VendingMachine {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VendingMachine window = new VendingMachine();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VendingMachine() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 578, 462);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_8 = new JLabel("Vending Machine");
		lblNewLabel_8.setFont(new Font("�L�n������", Font.PLAIN, 30));
		lblNewLabel_8.setForeground(new Color(255, 0, 0));
		lblNewLabel_8.setBounds(157, 34, 311, 52);
		frame.getContentPane().add(lblNewLabel_8);
		
		JPanel panel = new JPanel();
		panel.setBounds(14, 75, 532, 340);
		frame.getContentPane().add(panel);
		
		JRadioButton cokecolaRB = new JRadioButton("CokeCola");
				
		JRadioButton waterRB = new JRadioButton("Water");
		
		JRadioButton milkRB = new JRadioButton("MilkTea");
		
		JRadioButton blackRB = new JRadioButton("BlackTea");
		
		JRadioButton coffeeRB = new JRadioButton("Coffee");
		
		JRadioButton beerRB = new JRadioButton("Beer");
		
		JButton button = new JButton("Purchase");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try{
				double money =0;
				
				money= Double.parseDouble(textField.getText());
				if(cokecolaRB.isSelected()){
					money=money-25;
				}
				else if(waterRB.isSelected()){
					money=money-10;
				}
				else if(milkRB.isSelected()){
					money=money-20;
				}
				else if(blackRB.isSelected()){
					money=money-20;
				}
				else if(coffeeRB.isSelected()){
					money=money-25;
				}
				else if(beerRB.isSelected()){
					money=money-45;
				}
				
				if(money<0){
					JOptionPane.showMessageDialog(frame, "Sorry,you don't have enough money!");
				}
				else{
					textField_1.setText(Double.toString(money));
				}
				}
				catch (NumberFormatException e){
					JOptionPane.showMessageDialog(frame, "�Ч�J���T���B!");
				}
				
			}
		});
		
		JButton button_1 = new JButton("Clear");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				cokecolaRB.setSelected(false);
				waterRB.setSelected(false);
				milkRB.setSelected(false);
				blackRB.setSelected(false);
				coffeeRB.setSelected(false);
				beerRB.setSelected(false);
				textField.setText(" ");
				textField_1.setText("");
				
			}
		});

		JButton btnExit = new JButton("Exit");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				System.exit(0);
			
			}
		});
		
		
		cokecolaRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (cokecolaRB.isSelected()){
					waterRB.setSelected(false);
					milkRB.setSelected(false);
					blackRB.setSelected(false);
					coffeeRB.setSelected(false);
					beerRB.setSelected(false);
				}
			}
		});
		waterRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (waterRB.isSelected()){
					cokecolaRB.setSelected(false);
					milkRB.setSelected(false);
					blackRB.setSelected(false);
					coffeeRB.setSelected(false);
					beerRB.setSelected(false);
				}
			}
		});
		milkRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (milkRB.isSelected()){
					waterRB.setSelected(false);
					cokecolaRB.setSelected(false);
					blackRB.setSelected(false);
					coffeeRB.setSelected(false);
					beerRB.setSelected(false);
				}
			}
		});
		blackRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (blackRB.isSelected()){
					waterRB.setSelected(false);
					milkRB.setSelected(false);
					cokecolaRB.setSelected(false);
					coffeeRB.setSelected(false);
					beerRB.setSelected(false);
				}
			}
		});
		beerRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (beerRB.isSelected()){
					cokecolaRB.setSelected(false);
					waterRB.setSelected(false);
					milkRB.setSelected(false);
					blackRB.setSelected(false);
					coffeeRB.setSelected(false);
					
				}
			}
		});
		coffeeRB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (coffeeRB.isSelected()){
					waterRB.setSelected(false);
					milkRB.setSelected(false);
					blackRB.setSelected(false);
					beerRB.setSelected(false);
					cokecolaRB.setSelected(false);
				}
			}
		});
		
		JLabel label = new JLabel("$25");
		label.setFont(new Font("�s�ө���", Font.PLAIN, 15));
		
		JLabel label_1 = new JLabel("$20");
		
		JLabel label_2 = new JLabel("$10");
		
		JLabel label_3 = new JLabel("$25");
		
		JLabel label_4 = new JLabel("$20");
		
		JLabel label_5 = new JLabel("$45");
		
		JLabel label_6 = new JLabel("Insert Money : ");
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JLabel label_7 = new JLabel("Return Money :");
		
		textField_1 = new JTextField();
		textField_1.setEditable(false);
		textField_1.setColumns(10);
		
		
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
							.addGap(4)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_7, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
							.addGap(4)
							.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(cokecolaRB, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(label, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
							.addGap(36)
							.addComponent(waterRB, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
							.addGap(23)
							.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(milkRB, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
							.addGap(13)
							.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(blackRB, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE)
							.addGap(23)
							.addComponent(coffeeRB, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE)
							.addGap(8)
							.addComponent(beerRB, GroupLayout.PREFERRED_SIZE, 83, GroupLayout.PREFERRED_SIZE)
							.addGap(10)
							.addComponent(label_5, GroupLayout.PREFERRED_SIZE, 57, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(38)
							.addComponent(button, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
							.addGap(63)
							.addComponent(button_1, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)
							.addGap(60)
							.addComponent(btnExit, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(20, Short.MAX_VALUE))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel.createSequentialGroup()
					.addContainerGap(24, Short.MAX_VALUE)
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(3)
							.addComponent(label_6, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addGap(22)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(3)
							.addComponent(label_7, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addGap(39)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(cokecolaRB, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(4)
							.addComponent(label, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
						.addComponent(waterRB, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(4)
							.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
						.addComponent(milkRB, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(4)
							.addComponent(label_4, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE)))
					.addGap(44)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(blackRB, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(4)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
						.addComponent(coffeeRB, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(4)
							.addComponent(label_3, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE))
						.addComponent(beerRB, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(4)
							.addComponent(label_5, GroupLayout.PREFERRED_SIZE, 19, GroupLayout.PREFERRED_SIZE)))
					.addGap(30)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(button, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(button_1, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnExit, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE))
					.addGap(22))
		);
		panel.setLayout(gl_panel);
	}
}
