import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import java.awt.Panel;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.Font;

public class VendingMachine {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VendingMachine window = new VendingMachine();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VendingMachine() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 578, 462);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("CokeCola");
		rdbtnNewRadioButton.setBounds(32, 232, 83, 27);
		frame.getContentPane().add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Water");
		rdbtnNewRadioButton_1.setBounds(205, 232, 68, 27);
		frame.getContentPane().add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("MilkTea");
		rdbtnNewRadioButton_2.setBounds(363, 232, 83, 27);
		frame.getContentPane().add(rdbtnNewRadioButton_2);
		
		JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("BlackTea");
		rdbtnNewRadioButton_3.setBounds(32, 303, 83, 27);
		frame.getContentPane().add(rdbtnNewRadioButton_3);
		
		JRadioButton rdbtnNewRadioButton_4 = new JRadioButton("Coffee");
		rdbtnNewRadioButton_4.setBounds(205, 303, 83, 27);
		frame.getContentPane().add(rdbtnNewRadioButton_4);
		
		JRadioButton rdbtnNewRadioButton_5 = new JRadioButton("Beer");
		rdbtnNewRadioButton_5.setBounds(363, 303, 83, 27);
		frame.getContentPane().add(rdbtnNewRadioButton_5);
		
		JButton btnNewButton = new JButton("Purchase");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(70, 360, 99, 27);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Clear");
		btnNewButton_1.setBounds(232, 360, 99, 27);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("$25");
		lblNewLabel.setFont(new Font("�s�ө���", Font.PLAIN, 15));
		lblNewLabel.setBounds(125, 236, 44, 19);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("$20");
		lblNewLabel_1.setBounds(125, 307, 57, 19);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("$10");
		lblNewLabel_2.setBounds(296, 236, 57, 19);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("$25");
		lblNewLabel_3.setBounds(298, 307, 57, 19);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("$20");
		lblNewLabel_4.setBounds(459, 236, 57, 19);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("$45");
		lblNewLabel_5.setBounds(456, 307, 57, 19);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Insert Money : ");
		lblNewLabel_6.setBounds(32, 124, 99, 19);
		frame.getContentPane().add(lblNewLabel_6);
		
		textField = new JTextField();
		textField.setBounds(135, 121, 116, 25);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Return Money :");
		lblNewLabel_7.setBounds(32, 171, 99, 19);
		frame.getContentPane().add(lblNewLabel_7);
		
		textField_1 = new JTextField();
		textField_1.setBounds(135, 168, 116, 25);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Vending Machine");
		lblNewLabel_8.setFont(new Font("�L�n������", Font.PLAIN, 30));
		lblNewLabel_8.setForeground(new Color(255, 0, 0));
		lblNewLabel_8.setBounds(157, 34, 311, 52);
		frame.getContentPane().add(lblNewLabel_8);
		
		JButton btnNewButton_2 = new JButton("Cancel");
		btnNewButton_2.setBounds(391, 360, 99, 27);
		frame.getContentPane().add(btnNewButton_2);
	}
}
